import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './Components/login/login.component';
import { LogoutComponent } from './Components/logout/logout.component';
import { afterLoginGuard } from './Services/after-login.guard';
import { beforeLoginGuard } from './Services/before-login.guard';
import { NotfoundComponent } from './Layout/notfound/notfound.component';
import { HomeComponent } from './Layout/home/home.component';
import { RoomsComponent } from './Components/rooms/rooms.component';

const routes: Routes = [
  {
    path:'',
    redirectTo:'home',
    pathMatch:'full'
  },
  {
    path:'home',
    component : HomeComponent,
    canActivate:[afterLoginGuard]
  },
  {
    path:'login',
    component:LoginComponent,
    canActivate:[beforeLoginGuard]
  },
  {
    path:'logout',
    component:LogoutComponent,
    canActivate:[afterLoginGuard]
  },
  {
    path:'rooms',
    component:RoomsComponent,
    canActivate:[afterLoginGuard]
  },
  {
    path:'**',
    component:NotfoundComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
